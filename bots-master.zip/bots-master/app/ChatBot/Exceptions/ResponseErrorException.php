<?php

namespace WebXID\BotsMaster\ChatBot\Exceptions;

class ResponseErrorException extends \RuntimeException
{

}
